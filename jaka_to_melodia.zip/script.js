const songs = [
    { title: "Dziwny jest ten świat", file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" },
    { title: "Małgośka", file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" },
];

let currentSong = null;

document.getElementById("playButton").addEventListener("click", () => {
    currentSong = songs[Math.floor(Math.random() * songs.length)];
    const audio = new Audio(currentSong.file);
    audio.play();
});

document.getElementById("checkButton").addEventListener("click", () => {
    const userAnswer = document.getElementById("answerInput").value;
    const result = document.getElementById("result");
    if (userAnswer.toLowerCase() === currentSong.title.toLowerCase()) {
        result.textContent = "Brawo! Poprawna odpowiedź!";
    } else {
        result.textContent = `Niestety, to była: ${currentSong.title}`;
    }
});